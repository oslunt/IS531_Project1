from django.contrib import admin
from .models import DonutInfo

# Register your models here.

admin.site.register(DonutInfo)